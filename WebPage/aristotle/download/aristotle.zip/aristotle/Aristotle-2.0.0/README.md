# aristotle
Git repository for Aristotle - Computational Argumentation software

	Copyright (c) 2013-2016 PEREIRA, S.L.; SANTOS, L.F.Z.; LIRA, L.N..
	Department of Information Technology - São Paulo Technological College (FATEC-SP/CEETEPS).

	Older version available at http://www.ime.usp.br/~slago/aristotle.zip

	This is free software. There is ABSOLUTELY NO WARRANTY.
	Read LICENSE.txt for further information.
